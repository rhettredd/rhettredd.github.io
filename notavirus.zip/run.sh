./body.sh &
disown
exit