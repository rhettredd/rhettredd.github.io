while true; do
let var++
touch $HOME/Desktop/"$var".jpg
sleep 5
done